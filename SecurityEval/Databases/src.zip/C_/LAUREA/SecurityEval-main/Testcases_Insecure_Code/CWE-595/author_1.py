def isEqual(account1, account2):
    '''
    compare two accounts in the argument
    '''
    if account1 is account2:
        return True
    else:
        return False