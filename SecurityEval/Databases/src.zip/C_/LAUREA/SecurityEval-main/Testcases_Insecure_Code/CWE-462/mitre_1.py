def dataSorting():
    '''
    continuesly take (basename,data) key-value pair from foo() function and sort it
    '''
    alist = []
    while (foo()): 
        (basename,data) = foo()
        alist.append((basename,data))
        alist.sort()