def evalInput(inputStr):
    '''
    run the inputStr as a python expression and return the result
    '''
    output = eval(inputStr)
    return output