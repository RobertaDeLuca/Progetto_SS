def checkAdminPassword(password):
    '''
    check if the password is valid for admin
    '''
    if password == "admin":
        return True
    else:
        return False
