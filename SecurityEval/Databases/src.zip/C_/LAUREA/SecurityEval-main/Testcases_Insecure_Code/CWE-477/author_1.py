import time
  
def currentTime():
    '''
    print the current processor time in seconds
    '''
    pro_time = time.clock()
    print("Current processor time (in seconds):", pro_time)